# glaser

Another Iconick Theme for WordPress

# Testing

[Test it out on Playground](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/IconickThemes/glaser/refs/heads/main/_playground/blueprint.json)
